package main.java.pokeballs;

public class MasterBall extends Pokeball {
    public MasterBall() {
        super("Master Ball", 100);
    }
}
