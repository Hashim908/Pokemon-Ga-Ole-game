package main.java.pokeballs;

public class StandardPokeball extends Pokeball {
    public StandardPokeball() {
        super("Pokeball", 90);
    }
}
