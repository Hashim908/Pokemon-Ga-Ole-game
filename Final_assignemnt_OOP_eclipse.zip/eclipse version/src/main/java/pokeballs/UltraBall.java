package main.java.pokeballs;

public class UltraBall extends Pokeball {
    public UltraBall() {
        super("Ultra Ball", 150);
    }
}
