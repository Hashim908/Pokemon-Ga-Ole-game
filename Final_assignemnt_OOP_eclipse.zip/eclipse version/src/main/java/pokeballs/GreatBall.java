package main.java.pokeballs;

public class GreatBall extends Pokeball {
    public GreatBall() {
        super("Great Ball", 125);
    }
}
